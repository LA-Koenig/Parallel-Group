There is a makefile included in the folder that will compile the c++ code
using a g++ compiler on a linux system. Currently the c++ code lacks a working
example so it won't do anything when it compiles.
