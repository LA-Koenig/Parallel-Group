These are a collection of finite element solvers written in Julia that are known to work well.
They currently are not adapted to run with the specififcs of our project.

ParaPDE.jl is a julia module for parabolic pde solvers
PDEsFinal is a type of julia notebook called a pluto notebook that contains the setup and runs of various pde solutions.
It is best viewed with the Pluto notebook environment.